# Responsive Quiz App Using Spring Boot

MCQ based quiz application using Spring Boot, Spring Data JPA, MySQL, Thymeleaf and Bootstrap 5.



---

### Start Page

![Start Page](https://raw.githubusercontent.com/DevRezaur/spring-boot-quiz-app/refs/heads/main/screenshots/Start%20Page.PNG)

### Quiz Page

![Quiz Page 1](https://raw.githubusercontent.com/DevRezaur/spring-boot-quiz-app/refs/heads/main/screenshots/Quiz%20Page%201.PNG)

![Quiz Page 2](https://raw.githubusercontent.com/DevRezaur/spring-boot-quiz-app/refs/heads/main/screenshots/Quiz%20Page%202.PNG)

### Result Page

![Result Page](https://raw.githubusercontent.com/DevRezaur/spring-boot-quiz-app/refs/heads/main/screenshots/Result%20Page.PNG)

### Score Board

![Score Board](https://raw.githubusercontent.com/DevRezaur/spring-boot-quiz-app/refs/heads/main/screenshots/Score%20Board.PNG)

---

### Have a nice day
